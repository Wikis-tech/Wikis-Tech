"use server";
import {revalidatePath} from "next/cache";import {requireCmsUser} from "@/lib/auth/require-cms-user";import {createClient} from "@/lib/supabase/server";
const txt=(v:FormDataEntryValue|null)=>{const s=String(v??"").trim();return s||null};const num=(v:FormDataEntryValue|null)=>{const n=Number(v);return Number.isFinite(n)?n:0};
export async function saveAbout(fd:FormData){
 const u=await requireCmsUser(),s=await createClient();
 const payload={
  headline:String(fd.get("headline")??"").trim(),
  introduction:String(fd.get("introduction")??"").trim(),
  biography:txt(fd.get("biography")),
  philosophy:txt(fd.get("philosophy")),
  location:txt(fd.get("location")),
  availability:txt(fd.get("availability")),
  portrait_url:txt(fd.get("portraitUrl")),
  resume_url:txt(fd.get("resumeUrl")),
  is_published:fd.get("published")==="on",
  updated_by:u.id,updated_at:new Date().toISOString()
 };
 const {data,error}=await s.from("about_profile").update(payload).eq("singleton_key","default").select("id").maybeSingle();
 if(error){console.error("About profile update failed",error.code);throw new Error("Could not save your About details. Please retry.");}
 if(!data)throw new Error("About profile was not found or you do not have permission to edit it. No changes were saved.");
 const {error:logError}=await s.from("activity_logs").insert({user_id:u.id,action:"About profile updated",entity_type:"about"});
 if(logError)console.error("About update activity logging failed",logError.code);
 revalidatePath("/");revalidatePath("/about");revalidatePath("/admin/about");
}
export async function addJourney(fd:FormData){const u=await requireCmsUser(),s=await createClient();await s.from("journey_items").insert({title:String(fd.get("title")??"").trim(),description:txt(fd.get("description")),date_label:txt(fd.get("dateLabel")),icon:txt(fd.get("icon")),sort_order:num(fd.get("sortOrder")),created_by:u.id,updated_by:u.id});revalidatePath("/about");revalidatePath("/admin/about")}
export async function saveJourney(fd:FormData){const u=await requireCmsUser(),s=await createClient(),id=String(fd.get("id"));await s.from("journey_items").update({title:String(fd.get("title")??"").trim(),description:txt(fd.get("description")),date_label:txt(fd.get("dateLabel")),sort_order:num(fd.get("sortOrder")),is_visible:fd.get("visible")==="on",updated_by:u.id,updated_at:new Date().toISOString()}).eq("id",id);revalidatePath("/about");revalidatePath("/admin/about")}
export async function deleteJourney(fd:FormData){await requireCmsUser();const s=await createClient();await s.from("journey_items").delete().eq("id",String(fd.get("id")));revalidatePath("/about");revalidatePath("/admin/about")}
export async function addEducation(fd:FormData){const u=await requireCmsUser(),s=await createClient();await s.from("education").insert({institution:String(fd.get("institution")??"").trim(),program:txt(fd.get("program")),qualification:txt(fd.get("qualification")),location:txt(fd.get("location")),start_year:fd.get("startYear")?Number(fd.get("startYear")):null,end_year:fd.get("endYear")?Number(fd.get("endYear")):null,is_current:fd.get("current")==="on",description:txt(fd.get("description")),sort_order:num(fd.get("sortOrder")),created_by:u.id,updated_by:u.id});revalidatePath("/about");revalidatePath("/admin/about")}
export async function saveEducation(fd:FormData){const u=await requireCmsUser(),s=await createClient(),id=String(fd.get("id"));await s.from("education").update({institution:String(fd.get("institution")??"").trim(),program:txt(fd.get("program")),qualification:txt(fd.get("qualification")),location:txt(fd.get("location")),start_year:fd.get("startYear")?Number(fd.get("startYear")):null,end_year:fd.get("endYear")?Number(fd.get("endYear")):null,is_current:fd.get("current")==="on",is_visible:fd.get("visible")==="on",description:txt(fd.get("description")),sort_order:num(fd.get("sortOrder")),updated_by:u.id,updated_at:new Date().toISOString()}).eq("id",id);revalidatePath("/about");revalidatePath("/admin/about")}
export async function deleteEducation(fd:FormData){await requireCmsUser();const s=await createClient();await s.from("education").delete().eq("id",String(fd.get("id")));revalidatePath("/about");revalidatePath("/admin/about")}